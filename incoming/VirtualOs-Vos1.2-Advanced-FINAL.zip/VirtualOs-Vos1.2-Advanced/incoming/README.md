# ZIP update inbox

Drop a VOS project ZIP in this folder (for example `VirtualOs-update.zip`) and push it, or run **VOS ZIP Sync + Build** manually and provide its repository path.

The workflow extracts the newest ZIP, overlays its project files onto the repository while protecting the workflow itself, rebuilds the C++20 WebAssembly core, synchronizes the browser runtime mirror, compiles the native C++20 compiler, validates the ABI 2 multi-app example, and uploads fresh project/browser ZIP artifacts.

For manual runs, enable **commit_changes** only when you want the synchronized source/WASM changes committed back to the branch.
